﻿using Linken_Mini.Models;
using Microsoft.EntityFrameworkCore;

namespace Linken_Mini.Data
{
    public class Linken_Mini_Context : DbContext
    {
        public Linken_Mini_Context(DbContextOptions<Linken_Mini_Context> options) : base(options)
        {
        }

      


        public DbSet<Users> Users { get; set; }
        public DbSet<Education> Educations { get; set; }
        public DbSet<Achievements> Achievements { get; set; }
        public DbSet<Projects> Projects { get; set; }
        public DbSet<Hobby> Hobbies { get; set; }
        public DbSet<WorkExperience> WorkExperiences { get; set; }
        public DbSet<Reference> Reference { get; set; }




        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Users>().ToTable("Users");
            modelBuilder.Entity<Education>().ToTable("Education");
            modelBuilder.Entity<Achievements>().ToTable("Achievements");
            modelBuilder.Entity<Hobby>().ToTable("Hobby");
            modelBuilder.Entity<Projects>().ToTable("Projects");
            modelBuilder.Entity<WorkExperience>().ToTable("WorkExperience");
            modelBuilder.Entity<Reference>().ToTable("Reference");


        }





    }
}