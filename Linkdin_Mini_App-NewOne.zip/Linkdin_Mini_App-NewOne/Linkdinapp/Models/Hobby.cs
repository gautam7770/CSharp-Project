﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Linken_Mini.Models
{
    public class Hobby
    {
        public int HobbyID { get; set; }
        public string Name { get; set; }

        public int UsersID { get; set; }
        public Users User { get; set; }
        
    }
}
