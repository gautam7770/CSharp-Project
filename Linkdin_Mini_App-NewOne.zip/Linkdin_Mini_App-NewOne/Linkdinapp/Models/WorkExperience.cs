﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Linken_Mini.Models
{
    public class WorkExperience
    {
        public int WorkExperienceID { get; set; }

        [Required]
        public string Area { get; set; }
        [Required]
        public string Position { get; set; }
        
        [Required]
        public string StartYear { get; set; }

        [Required]
        public string YearOfExperience { get; set; }
        [Required]
        public string EndYear { get; set; }
        [Required]
        public int UsersID { get; set; }
        public Users User { get; set; }
        public string Description { get; set; }
        public ICollection<Reference> References { get; set; }

    }
}
