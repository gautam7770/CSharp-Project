﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Linken_Mini.Models
{
    public class Reference
    {
        public int ReferenceID { get; set; }
        public string  Name{ get; set; }
        public string  CompanyName{ get; set; }
        public string  Role{ get; set; }
        public string  Position{ get; set; }
        public string  EmailId{ get; set; }
        public WorkExperience  workExperience{ get; set; }
        public int   WorkExperienceID{ get; set; }

    }
}
