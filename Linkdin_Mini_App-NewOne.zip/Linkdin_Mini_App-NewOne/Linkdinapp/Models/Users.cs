﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Linken_Mini.Models
{
    public class Users
    {
        public int UsersID { get; set; }
        [Required]  
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string PassWord { get; set; }
        [Required]
        public int MobileNo { get; set; }
        
        [Required]
        [EmailAddress]
        public string EmailId { get; set; }
        public ICollection<Education> Educations { get; set; }
        public ICollection<Achievements> Achievements { get; set; }
        public ICollection<Projects> Projects { get; set; }
        public ICollection<Hobby> Hobbies { get; set; }
        public ICollection<WorkExperience> WorkExperiences { get; set; }
       
    }
}
