﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Linken_Mini.Models
{
    public class Education
    {
        public int EducationID { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public double GPA { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime StartYear{ get; set; }
        [Required]
        public string CollegeName { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public string EndYear { get; set; }
        [Required]
        public int UsersID { get; set; }
        public Users Users { get; set; }
       
        
    }
}
