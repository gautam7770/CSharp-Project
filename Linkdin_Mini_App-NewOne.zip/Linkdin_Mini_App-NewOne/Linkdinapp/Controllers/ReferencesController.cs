﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Linken_Mini.Data;
using Linken_Mini.Models;

namespace Linken_Mini.Controllers
{
    public class ReferencesController : Controller
    {
        private readonly Linken_Mini_Context _context;

        public ReferencesController(Linken_Mini_Context context)
        {
            _context = context;
        }

        // GET: References
        public async Task<IActionResult> Index()
        {
            var linken_Mini_Context = _context.Reference.Include(r => r.workExperience);
            return View(await linken_Mini_Context.ToListAsync());
        }
        public async Task<IActionResult> IndexById(int UserId)
        {
            var linken_Mini_Context = _context.Reference.Include(h => h.workExperience);
            return View("Index", await linken_Mini_Context.ToListAsync());
        }
        // GET: References/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reference = await _context.Reference
                .Include(r => r.workExperience)
                .FirstOrDefaultAsync(m => m.ReferenceID == id);
            if (reference == null)
            {
                return NotFound();
            }

            return View(reference);
        }

        // GET: References/Create
        public IActionResult Create()
        {
            ViewData["WorkExperienceID"] = new SelectList(_context.WorkExperiences, "WorkExperienceID", "Area");
            return View();
        }

        // POST: References/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ReferenceID,Name,CompanyName,Role,Position,EmailId,WorkExperienceID")] Reference reference)
        {
            if (ModelState.IsValid)
            {
                _context.Add(reference);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["WorkExperienceID"] = new SelectList(_context.WorkExperiences, "WorkExperienceID", "Area", reference.WorkExperienceID);
            return View(reference);
        }

        // GET: References/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reference = await _context.Reference.FindAsync(id);
            if (reference == null)
            {
                return NotFound();
            }
            ViewData["WorkExperienceID"] = new SelectList(_context.WorkExperiences, "WorkExperienceID", "Area", reference.WorkExperienceID);
            return View(reference);
        }

        // POST: References/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ReferenceID,Name,CompanyName,Role,Position,EmailId,WorkExperienceID")] Reference reference)
        {
            if (id != reference.ReferenceID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(reference);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReferenceExists(reference.ReferenceID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["WorkExperienceID"] = new SelectList(_context.WorkExperiences, "WorkExperienceID", "Area", reference.WorkExperienceID);
            return View(reference);
        }

        // GET: References/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var reference = await _context.Reference
                .Include(r => r.workExperience)
                .FirstOrDefaultAsync(m => m.ReferenceID == id);
            if (reference == null)
            {
                return NotFound();
            }

            return View(reference);
        }

        // POST: References/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var reference = await _context.Reference.FindAsync(id);
            _context.Reference.Remove(reference);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReferenceExists(int id)
        {
            return _context.Reference.Any(e => e.ReferenceID == id);
        }
    }
}
